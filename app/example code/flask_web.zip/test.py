print("Now start")

def hello():
    print("Say hello")

def bye():
    print("See you")

# 이 파일을 실행해야 if문이 돌아감 - 메인 함수
if __name__ == "__main__":
    hello()
    bye()